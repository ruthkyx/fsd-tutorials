let colours = ["pink", "purple", "blue", "yellow"]
let removeLast = colours.pop();
console.log(colours);

let removeFirst = colours.shift();
console.log(colours);

console.log(`remove last: ${removeLast} \nremove first: ${removeFirst}`)