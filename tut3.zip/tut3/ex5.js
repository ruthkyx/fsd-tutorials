function rectangleArea (width, height) {
    return width * height;
}

let area = rectangleArea(2,3);
console.log(area);