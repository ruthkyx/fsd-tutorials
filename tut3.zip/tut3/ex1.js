let fruits = ["grapes", "watermelon"];
console.log(fruits);

fruits.push("mango");
console.log(fruits);

fruits.unshift("strawberry");
console.log(fruits);