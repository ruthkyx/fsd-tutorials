let integers = [
    [1, 2, 3],
    [4, 5, 6],
]
// print the element at the 2nd row 3rd column 
console.log("3rd element on the 2nd row is: ", integers[1][2])

integers[1][2] = 8;
console.log(integers);