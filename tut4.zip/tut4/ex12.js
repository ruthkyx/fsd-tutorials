const greet = () => 
    "hello world!";
console.log(greet());