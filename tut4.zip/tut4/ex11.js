let squareNum = (num1) => num1**2;
console.log(squareNum(2));