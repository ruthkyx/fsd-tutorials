let seating = [
    ['matthew', 'mark', 'luke', 'john'], 
    ['blossom', 'bubbles', 'buttercup', 'mojojojo'], 
    ['ruth', 'charissa', 'victory', 'jireh'],
    ['judi', 'shirley', 'isabelle', 'teresa'],
    ['pikachu', 'eevee', 'charizard', 'raichu']
]
console.log(seating);
seating[0][1] = 'eugene';
console.log(seating);