let traditional = (function(){
    console.log("hello world");
})();

let arrow = (() => {console.log("hello world")})();