let add = (a, b) => a+b;
console.log(add(1,2));