let products = [
    ["cleanser", 6.99, 5],
    ["toner", 15, 6],
    ["serum", 18, 3]
]
products[1][1] = 14;
console.log("updated inventory: ", products);