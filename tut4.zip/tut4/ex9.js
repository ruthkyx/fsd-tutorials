let sum = (function(num1, num2){
    return num1+num2;
})
console.log(sum(1,2));