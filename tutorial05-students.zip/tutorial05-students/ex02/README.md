# Create a media recipe HTML page
Based on your earlier code, add in embedded video resources, tables to showcase more info

Upgrade it using semantic HTML
