let x = 3;
let y = 8;
let firstName = "Charlie";
let raining = false;
let snowing = false;
let windy = true;
if (x + y > 10) {
console.log("Good!");
}
if (x - y < 0) {
console.log("Good!");
}
if (x + y >= 11) {
console.log("Good!");
}
if (y - x == 5) {
console.log("Good!");
}
if (x != y) {
console.log("Good!");
}
if (raining == false) {
console.log("Good!");
}
if (snowing != true) {
    console.log("Good!");
    }
    if (firstName == "Charlie") {
    console.log("Good!");
    }