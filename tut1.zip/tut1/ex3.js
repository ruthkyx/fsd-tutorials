// basic arithetic operations
const x = 3
const y = 4

const printvar = `the numbers are ${x} and ${y}` //must use backtick
console.log([printvar])

let sum = x + y;
console.log(sum);

const subtraction = y - x;
console.log(subtraction);

let multiplication = x*y
console.log(multiplication)

const division = y/1
console.log(division)

let modulus = y%x // modulus function to print out the remainder
console.log(modulus)