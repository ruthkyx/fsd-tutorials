let age = 25
let gst = 0.09
let isRaining = false
let username = "Samantha Brown"

console.log(age);
console.log(gst);
console.log(isRaining);
console.log(username);