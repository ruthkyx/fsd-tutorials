const prompt = require('prompt-sync')();
let num1 = prompt("Enter num1: ");
let num2 = prompt("Enter num2: ");

let product = num1*num2;
console.log(product);