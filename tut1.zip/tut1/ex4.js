var num1 = 3
var num2 = 4

let sum = num1 + num2
console.log(sum)

let minus = num1 - num2
console.log(minus)

let multiply = num1 * num2
console.log(multiply)

let divide = num1 / num2
console.log(divide)