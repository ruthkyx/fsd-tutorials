let length = 2
let width = 4
let area = length*width
console.log(`the area is ${area}cm^2`)