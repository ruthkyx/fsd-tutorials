let tempC = 36;
let degInF = (tempC*9/5) + 32; // Fahrenheit=(Celsius× 9/5)+32
console.log(`degree in celcius: ${tempC} \ndegree in fahrenheit is: ${degInF}`);