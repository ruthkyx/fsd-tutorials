const cost = 1.5
var numberOfDonuts = 20

let total = cost*numberOfDonuts
console.log(`the total cost is $${total}`)