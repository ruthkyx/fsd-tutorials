let p = 53 // number 
console.log(p)
console.log(typeof p) // typeof: data type of the variable

let food = 'pasta' // string
console.log(food)
console.log(typeof food)

let status = true // boolean
console.log(status)
console.log(typeof status) 

let x = null //null
console.log(x)
console.log(typeof x)

let y; //undefined


let z = 3.14 //float 
console.log(z)
console.log(typeof z) // how to make it a float?