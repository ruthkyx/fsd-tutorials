// muffin costs d dollars and c cents; mary bought n muffins

const d = 2
const c = 0.5
var n = 4

let total = (d+c)*n
console.log(`Mary has to pay $${total}`)