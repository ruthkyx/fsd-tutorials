let arr = [2, "hello", 5, "byebye"];
for(i = 0; i < arr.length; i++) {
    console.log(arr[i])
}