// for loop that countdown from 10 to 1 then prints "Liftoff!"

for(let i = 10; i >= 1 ; i--) {
    console.log(i);
}
console.log("Liftoff!");