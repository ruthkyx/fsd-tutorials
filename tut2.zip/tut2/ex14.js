let i = 3;
let j = 1;
while (j < 6) {
    console.log (i*j); 
    j = j + 1; // so that it'll become i * 1, i * 2 ....
}