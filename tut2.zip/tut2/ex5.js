// print even numbers from 2 to 20 

for(let i = 2; i <= 20; i += 2){
    console.log(i);
}